import { test } from '@playwright/test';
import { CreateArticlePage } from '../../src/ui/pages/article/CreateArticlePage';
import { ViewArticlePage } from '../../src/ui/pages/article/ViewArticlePage';
import { createNewArticle } from '../../src/ui/actions/article/createNewArticle';
import { signUpUser } from '../../src/ui/actions/auth/signUpUser';

test.describe('Edit article tests', () => {
  let createArticlePage;
  let viewArticlePage;

  const baseArticle = {
    title: 'Initial Title ' + Date.now(),
    description: 'Initial Description',
    text: 'Initial Text Body',
    tags: ['initial-tag'],
  };

  test.beforeEach(async ({ page }) => {
    createArticlePage = new CreateArticlePage(page);
    viewArticlePage = new ViewArticlePage(page);

    const randomUser = {
      username: 'user_' + Date.now(),
      email: `test_${Date.now()}@example.com`,
      password: 'Password123!',
    };

    await signUpUser(page, randomUser);
  });

  test('Edit the article title for the existing article', async ({ page }) => {
    await createNewArticle(page, baseArticle);

    await viewArticlePage.clickEditArticleButton();
    const updatedTitle = 'Updated Title ' + Date.now();
    await createArticlePage.fillTitleField(updatedTitle);
    await createArticlePage.clickPublishArticleButton();

    await viewArticlePage.assertArticleTitleIsVisible(updatedTitle);
  });

  test('Edit the article description for the existing article', async ({ page }) => {
    await createNewArticle(page, baseArticle);

    await viewArticlePage.clickEditArticleButton();
    const updatedDescription = 'Updated Description';
    await createArticlePage.fillDescriptionField(updatedDescription);
    await createArticlePage.clickPublishArticleButton();

    await viewArticlePage.assertArticleDescriptionIsVisible(updatedDescription);
  });

  test('Edit the article text for the existing article', async ({ page }) => {
    await createNewArticle(page, baseArticle);

    await viewArticlePage.clickEditArticleButton();
    const updatedText = 'Updated Text Body';
    await createArticlePage.fillTextField(updatedText);
    await createArticlePage.clickPublishArticleButton();

    await viewArticlePage.assertArticleTextIsVisible(updatedText);
  });

  test('Add the tag for the existing article without tags', async ({ page }) => {
    const articleWithoutTags = { ...baseArticle, tags: [] };
    await createNewArticle(page, articleWithoutTags);

    await viewArticlePage.clickEditArticleButton();
    const tag = 'new-tag';
    await createArticlePage.fillTagsField(tag);
    await createArticlePage.clickPublishArticleButton();

    await viewArticlePage.assertArticleTagIsVisible(tag);
  });

  test('Add the tag for the existing article with tags', async ({ page }) => {
    await createNewArticle(page, baseArticle);

    await viewArticlePage.clickEditArticleButton();
    const newTag = 'added-tag';
    await createArticlePage.fillTagsField(newTag);
    await createArticlePage.clickPublishArticleButton();

    await viewArticlePage.assertArticleTagIsVisible(newTag);
  });

  test('Remove an article tag for the existing article with tag', async ({ page }) => {
    await createNewArticle(page, baseArticle);

    await viewArticlePage.clickEditArticleButton();
    const tagToRemove = baseArticle.tags[0];
    await createArticlePage.removeTag(tagToRemove);
    await createArticlePage.clickPublishArticleButton();

    await viewArticlePage.assertArticleTagIsNotVisible(tagToRemove);
  });

  test('Remove an article title for the existing article', async ({ page }) => {
    await createNewArticle(page, baseArticle);

    await viewArticlePage.clickEditArticleButton();
    await createArticlePage.clearTitleField();
    await createArticlePage.clickPublishArticleButton();

    await createArticlePage.assertErrorMessageContainsText("Article title cannot be empty");
  });

  test('Remove an article description for the existing article', async ({ page }) => {
    await createNewArticle(page, baseArticle);

    await viewArticlePage.clickEditArticleButton();
    await createArticlePage.clearDescriptionField();
    await createArticlePage.clickPublishArticleButton();

    await createArticlePage.assertErrorMessageContainsText("Article description cannot be empty");
  });

  test('Remove the article text for the existing article', async ({ page }) => {
    await createNewArticle(page, baseArticle);

    await viewArticlePage.clickEditArticleButton();
    await createArticlePage.clearTextField();
    await createArticlePage.clickPublishArticleButton();

    await createArticlePage.assertErrorMessageContainsText("Article body cannot be empty");
  });

  test('Edit all fields for the existing article', async ({ page }) => {
    await createNewArticle(page, baseArticle);

    await viewArticlePage.clickEditArticleButton();

    const updatedTitle = 'Fully Updated Title ' + Date.now();
    const updatedDescription = 'Fully Updated Description';
    const updatedText = 'Fully Updated Text';
    const newTag = 'fully-updated-tag';

    await createArticlePage.fillTitleField(updatedTitle);
    await createArticlePage.fillDescriptionField(updatedDescription);
    await createArticlePage.fillTextField(updatedText);
    await createArticlePage.fillTagsField(newTag);
    await createArticlePage.clickPublishArticleButton();

    await viewArticlePage.assertArticleTitleIsVisible(updatedTitle);
    await viewArticlePage.assertArticleDescriptionIsVisible(updatedDescription);
    await viewArticlePage.assertArticleTextIsVisible(updatedText);
    await viewArticlePage.assertArticleTagIsVisible(newTag);
  });
});