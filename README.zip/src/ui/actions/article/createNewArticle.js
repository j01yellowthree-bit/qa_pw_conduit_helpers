import { CreateArticlePage } from '../../pages/article/CreateArticlePage';

export async function createNewArticle(page, articleData) {
  const createArticlePage = new CreateArticlePage(page);

  await page.goto('/editor');

  await createArticlePage.fillTitleField(articleData.title);
  await createArticlePage.fillDescriptionField(articleData.description);
  await createArticlePage.fillTextField(articleData.text);

  if (articleData.tags && articleData.tags.length > 0) {
    for (const tag of articleData.tags) {
      await createArticlePage.fillTagsField(tag);
    }
  }

  await createArticlePage.clickPublishArticleButton();
}