import { expect, test } from '@playwright/test';

export class CreateArticlePage {
  constructor(page) {
    this.page = page;

    this.titleField = page.getByPlaceholder('Article Title');
    this.descriptionField = page.getByPlaceholder("What's this article about?");
    this.textField = page.getByPlaceholder('Write your article (in markdown)');
    this.tagsField = page.getByPlaceholder('Enter tags');

    this.publishArticleButton = page.getByRole('button', {
      name: /(Publish|Update) Article/i,
    });

    this.errorMessage = page.locator('.error-messages');
  }

  async fillTitleField(title) {
    await test.step(`Fill the 'Title' field`, async () => {
      await this.titleField.click();
      await this.titleField.clear();
      await this.titleField.fill(title);
      await this.titleField.blur();
    });
  }

  async clearTitleField() {
    await test.step(`Clear the 'Title' field`, async () => {
      await this.titleField.click();
      await this.titleField.clear();
      await this.titleField.blur();
    });
  }

  async fillDescriptionField(description) {
    await test.step(`Fill the 'Description' field`, async () => {
      await this.descriptionField.click();
      await this.descriptionField.clear();
      await this.descriptionField.fill(description);
      await this.descriptionField.blur();
    });
  }

  async clearDescriptionField() {
    await test.step(`Clear the 'Description' field`, async () => {
      await this.descriptionField.click();
      await this.descriptionField.clear();
      await this.descriptionField.blur();
    });
  }

  async fillTextField(text) {
    await test.step(`Fill the 'Text' field`, async () => {
      await this.textField.click();
      await this.textField.clear();
      await this.textField.fill(text);
      await this.textField.blur();
    });
  }

  async clearTextField() {
    await test.step(`Clear the 'Text' field`, async () => {
      await this.textField.click();
      await this.textField.clear();
      await this.textField.blur();
    });
  }

  async fillTagsField(tag) {
    await test.step(`Fill the 'Tags' field`, async () => {
      await this.tagsField.fill(tag);
      await this.tagsField.press('Enter');
    });
  }

  async removeTag(tagName) {
    await test.step(`Remove tag '${tagName}'`, async () => {
      const tagRemoveIcon = this.page
        .locator('.tag-default', { hasText: tagName })
        .locator('i');
      await tagRemoveIcon.click();
    });
  }

  async clickPublishArticleButton() {
    await test.step(`Click the 'Publish Article' button`, async () => {
      await Promise.all([
        this.page.waitForResponse(response =>
          response.url().includes('/api/articles') &&
          ['POST', 'PUT'].includes(response.request().method())
        ).catch(() => null),
        this.publishArticleButton.click(),
      ]);
      await this.page.waitForTimeout(500);
    });
  }

  async assertErrorMessageContainsText(messageText) {
    await test.step(`Assert the '${messageText}' error is shown`, async () => {
      await expect(this.errorMessage).toContainText(messageText);
    });
  }
}