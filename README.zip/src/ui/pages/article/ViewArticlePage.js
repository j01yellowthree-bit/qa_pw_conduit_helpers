import { test, expect } from '@playwright/test';

export class ViewArticlePage {
  constructor(page) {
    this.page = page;
    this.articleTitleHeader = page.locator('h1');
    this.editArticleButton = page.getByRole('link', { name: 'Edit Article' }).first();
    this.articleBody = page.locator('.article-content');
    this.tagsList = page.locator('.tag-list');
  }

  async clickEditArticleButton() {
    await test.step(`Click the 'Edit Article' button`, async () => {
      await this.editArticleButton.click();
    });
  }

  async assertArticleTitleIsVisible(title) {
    await test.step(`Assert the article has correct title`, async () => {
      await expect(this.page.locator('h1').first()).toContainText(title);
    });
  }

  async assertArticleDescriptionIsVisible(description) {
    await test.step(`Assert the article has correct description`, async () => {
      await this.clickEditArticleButton();
      await expect(this.page.getByPlaceholder("What's this article about?")).toHaveValue(description);
    });
  }

  async assertArticleTextIsVisible(text) {
    await test.step(`Assert the article has correct text`, async () => {
      await expect(this.page.getByText(text)).toBeVisible();
    });
  }

  async assertArticleTagIsVisible(tagName) {
    await test.step(`Assert the tag '${tagName}' is visible`, async () => {
      await expect(this.tagsList.getByText(tagName)).toBeVisible();
    });
  }

  async assertArticleTagIsNotVisible(tagName) {
    await test.step(`Assert the tag '${tagName}' is NOT visible`, async () => {
      await expect(this.tagsList.getByText(tagName)).not.toBeVisible();
    });
  }
}